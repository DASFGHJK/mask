# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html


# useful for handling different item types with a single interface
from itemadapter import ItemAdapter

import pandas as pd
from scrapy.exceptions import DropItem

class SaveToExcelPipeline:
    def __init__(self):
        self.items = []

    def process_item(self, item, spider):
        self.items.append(dict(item))
        return item

    def close_spider(self, spider):
        df = pd.DataFrame(self.items, columns=['title', 'abstract','author', 'shortName', 'fixedPrice', 'wordCount'])
        df.to_excel('douban_data.xlsx', index=False)
        spider.logger.info("数据已保存到 douban_data.xlsx")
